﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalOPD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //comboBox1.SelectedIndex = 2;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string p_first_name = textBox1.Text;
            string p_last_name = textBox2.Text;
            string ph_first_name = textBox4.Text;
            string ph_last_name = textBox3.Text;

            if ( richTextBox1.Text.Length == 0 || ph_first_name.Length == 0 || ph_last_name.Length == 0 || p_first_name.Length == 0 || p_last_name.Length == 0 || check(ph_first_name) || check(ph_last_name) || check(p_first_name) || check(p_last_name))
            {
                MessageBox.Show("Enter the Valid Field...");
                return;
            }

            MessageBox.Show("Regestation Successfully....");
        }

        private bool check(string str)
        {
            for(int i = 0; i < str.Length; ++i)
            {
                if (!(str[i] >= 'A' && str[i] <= 'Z') && !(str[i] >= 'a' && str[i] <= 'z'))
                    return true;
            }
            return false;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
