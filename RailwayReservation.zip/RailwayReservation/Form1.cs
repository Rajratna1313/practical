﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == textBox2.Text)
            {
                MessageBox.Show("Source and Destination should not be same");
                textBox1.Clear();
                textBox2.Clear();
            }


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //richTextBox1.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string name = textBox4.Text;
            string age = textBox3.Text;

            if (name.Length == 0 || age.Length == 0 || check(name))
            {
                MessageBox.Show("Enter valid Filed..");
            }

            for (int i = 0; i < age.Length; ++i)
            {
                if (age[i] >= '0' && age[i] <= '9')
                {
                    continue;
                }

                MessageBox.Show("Enter valid Filed..");
                return;
            }
           // string name = textBox4.Text;
            //string age = textBox3.Text;

            richTextBox1.Text = $"Name: {name} Age: {age}";

            MessageBox.Show("added succesfully");


        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || check(textBox1.Text) || check(textBox2.Text))
            {
                MessageBox.Show("Source and Destination should be valid");
                return;
            }

            if (comboBox1.Items.Count == 0 || comboBox2.Items.Count == 0 || (!checkBox1.Checked && !checkBox2.Checked && !checkBox3.Checked && !checkBox4.Checked))
            {
                MessageBox.Show("All Filed are compoulsory...");
                return;
            }
            if (textBox1.Text == textBox2.Text)
            {
                MessageBox.Show("Source and Destination should not be same");
                textBox1.Clear();
                textBox2.Clear();
            }

            MessageBox.Show("Ticket is Availabel..");

        }

        private bool check(string str)
        {
            for (int i = 0; i < str.Length; ++i)
            {
                if (!(str[i] >= 'A' && str[i] <= 'Z') && !(str[i] >= 'a' && str[i] <= 'z'))
                    return true;
            }
            return false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string name = textBox4.Text;
            string age = textBox3.Text;

            richTextBox1.Text = $"Name: {name} Age: {age}";
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("ticket is booked");
        }
    }
}
