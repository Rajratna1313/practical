﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T_Shirt_Orders
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void order_click(object sender, EventArgs e)
        {
            string small = textBox1.Text;
            string medium = textBox3.Text;
            string large = textBox4.Text;
            string promocode = textBox2.Text;

            if(small.Length == 0 && medium.Length == 0 && large.Length == 0)
            {
                MessageBox.Show("Enter the TShirt Quantity...");
                return;
            }

            if(check(small) ||  check(medium) || check(large))
            {
                MessageBox.Show("Enter Valid Fileds...");
                return;
            }

            int small_price = Convert.ToInt32(small) * 125;
            int medium_price = Convert.ToInt32(medium) * 175;
            int large_price = Convert.ToInt32(large) * 250;

            double total = small_price + medium_price + large_price;

            if (promocode == "TRUEBLUE")
            { 
                total = total - ((total / 100) * 10);
            }

            total = total + ((total / 100) * 9);

            label5.Text = "Total Price: " +  total.ToString();


        }

        private bool check(string str)
        {
            for(int i = 0; i < str.Length; ++i)
            {
                if (str[i] >= '0' && str[i] <= '9')
                    continue;
                return true;
            }

            return false;
        }

        private void clear_click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void on_load(object sender, EventArgs e)
        {
        }
    }
}
